#ifndef PI_H
#define PI_H

// Fonction qui calcule la nouvelle valeur de commande PWM
float PI_controller(long erreur);

#endif
