#include "PID.h"
#include <avr/io.h>
#include <stdint.h>
#include "VirtualSerial.h"

float PID(float consigne, float freq_mesure) {
    static const float Kp = 0.02f;    /* 1200 * 0.02  = 24  -> correction significative  */
    static const float Ki = 0.002f;   /* integrale assez rapide pour corriger le biais    */
    static const float Kd = 0.005f;   /* amortissement pour eviter les oscillations       */

    static float integrale    = 0.0f;
    static float erreur_avant = 0.0f;
    static float dt           = 1.0f;

    float erreur   = freq_mesure;
    integrale     += erreur * dt;
    sature_integrale(&integrale);
    float derivee  = (erreur - erreur_avant) / dt;

    float commande_pwm = Kp * erreur + Ki * integrale + Kd * derivee;
    commande_pwm = sature_commande(commande_pwm);
    erreur_avant = erreur;
    return commande_pwm;
}

void sature_integrale(float *integrale) {
    const float integrale_max = 1000.0f;
    if (*integrale >  integrale_max) *integrale =  integrale_max;
    else if (*integrale < -integrale_max) *integrale = -integrale_max;
}

float sature_commande(float commande) {
    if (commande >  50.0f) return  50.0f;
    if (commande < -50.0f) return -50.0f;
    return commande;
}
