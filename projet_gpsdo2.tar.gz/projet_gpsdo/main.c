#include <avr/io.h>
#include <stdint.h>
#include <stdio.h>
#include "inputcap.h"
#include "VirtualSerial.h"
#include "PI.h"

/* --- CONFIGURATION --- */
#define F_CPU_HZ        16000000L
#define TARGET_CYCLES   16000000L   /* Cycles attendus par periode GPS              */
#define PWM_CENTER      512         /* Point neutre 50% duty cycle (10 bits)        */
#define PWM_SCALE       10          /* commande (+-50) -> delta PWM (+-500)         */
//#define ERR_MAX         5000L       /* Seuil filtre spikes overflow Timer            */
#define ERR_MAX 100000L  // On augmente le seuil pour accepter plus d'erreurs au début

extern USB_ClassInfo_CDC_Device_t VirtualSerial_CDC_Interface;
extern FILE USBSerialStream;

/* --- Ecriture PWM Timer 4 (10 bits) ---
 * TC4H DOIT etre ecrit AVANT OCR4D, toujours.              */
static void set_pwm(int16_t val)
{
    if (val > 1023) val = 1023;
    if (val < 0)    val = 0;
    TC4H  = ((uint16_t)val >> 8);
    OCR4D = ((uint16_t)val & 0xFF);
}

/* --- SECTION PWM (TIMER 4) - CONFIGURATION PD7 --- */
void init_pwm_timer4(void)
{
    DDRD  |= (1 << PD7);

    TC4H   = (1023 >> 8);
    OCR4C  = (1023 & 0xFF);

    TC4H   = (512 >> 8);
    OCR4D  = (512 & 0xFF);

    TCCR4C = (1 << COM4D1) | (1 << PWM4D);
    TCCR4B = (1 << CS40);
}

/* =================================  MAIN  ============================= */
int main(void)
{
    char buffer[64];

    SetupHardware();
    CDC_Device_CreateStream(&VirtualSerial_CDC_Interface, &USBSerialStream);

    init_pwm_timer4();

    DDRD &= ~(1 << PD4);
    setup_input_capture();

    GlobalInterruptEnable();

    signed long raw_cycles;
    signed long err_raw;
    float       commande;
    int16_t     pwm_val;

while (1)
    {
        raw_cycles = measure_cycles();
        //err_raw = raw_cycles - TARGET_CYCLES; CAR IL FAISAIT LE PI A L ENVERS PWM AUGMENTE AVCE CMD ET L ERREUR
		err_raw = TARGET_CYCLES - raw_cycles;
        // FILTRE TRÈS IMPORTANT : 
        // On n'accepte que si l'erreur est "humaine" (entre -2000 et 2000 cycles)
        // Les erreurs de 66000 sont des erreurs de comptage Timer, on les ignore !
        if (err_raw < 2000 && err_raw > -2000)
        {
            // On calcule le PI uniquement sur les bonnes mesures
            commande = PI_controller(err_raw);

            pwm_val = (int16_t)(PWM_CENTER + commande);
            
            if (pwm_val > 1023) pwm_val = 1023;
            if (pwm_val < 0)    pwm_val = 0;
            
            set_pwm(pwm_val);

            // Affichage propre
            sprintf(buffer, "Cycles:%ld Err:%ld Cmd:%d PWM:%d\r\n",
                    raw_cycles, err_raw, (int)commande, (int)pwm_val);
            fputs(buffer, &USBSerialStream);
        }
        else
        {
            // Si c'est un spike (66000), on n'appelle pas le PI, on n'affiche rien 
            // ou juste un message de debug. Le PWM reste à sa valeur précédente.
        }

        CDC_Device_USBTask(&VirtualSerial_CDC_Interface);
        USB_USBTask();
    }

    return 0;
}
