#include "PI.h"

static float integrale_cumulee = 0.0f;

float PI_controller(long erreur) {
    float Kp = 0.005f;  
    float Ki = 0.02f;   
    
    integrale_cumulee += (float)erreur;

    // 1. ON ÉLARGIT LA LIMITE DE L'INTÉGRALE (de 10000 à 25000)
    // 25000 * 0.02 = 500. On a maintenant assez de force !
    if (integrale_cumulee > 25000.0f)  integrale_cumulee = 25000.0f;
    if (integrale_cumulee < -25000.0f) integrale_cumulee = -25000.0f;

    float p_term = Kp * (float)erreur;
    float i_term = Ki * integrale_cumulee;
    
    float resultat = p_term + i_term;

    // 2. ON ÉLARGIT LA LIMITE DE COMMANDE (de +/- 400 à +/- 500)
    // Cela permet au PWM d'aller de 12 à 1012 (pratiquement 0 à 1023)
    if (resultat > 500.0f)  resultat = 500.0f;
    if (resultat < -500.0f) resultat = -500.0f;

    return resultat;
}
